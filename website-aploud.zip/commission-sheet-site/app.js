/* Commission Sheet — tampilan & logika halaman (tanpa ketergantungan platform apa pun) */
(function () {
"use strict";

/* ---------- language ---------- */
const T={
id:{nav_beranda:"Beranda",nav_harga:"Harga",nav_galeri:"Galeri",nav_antrean:"Antrean",nav_ketentuan:"Ketentuan",
  st_open:"Open",st_waitlist:"Waitlist",st_closed:"Closed",k_open:"✦ Open commission",k_waitlist:"✦ Waitlist dibuka",k_closed:"✦ Commission ditutup",k_none:"✦ Commission",
  loading:"Memuat sheet…",artistDefault:"Nama artis",taglineDefault:"Harga, slot, dan antrean komisi tampil di sini.",taglineEditor:"Buka mode edit untuk mengisi profil, harga, dan antrean.",
  loadFail:"Data belum bisa dimuat. Coba muat ulang halaman.",notConfigured:"Penyimpanan belum diatur. Isi config.js sesuai README.",
  seePrices:"Lihat harga",copyContact:"Salin kontak",artHintEditor:"Unggah artwork terbaikmu di mode edit agar tampil di sini.",artHint:"Artwork utama akan tampil di sini.",uploadArt:"Unggah artwork",changeArt:"Ganti artwork",changeAvatar:"Ganti foto profil",
  chipLeft:"<b>{n}</b> slot tersisa",chipFrom:"mulai <b>{p}</b>",
  slotsMonth:"Slot bulan ini",orderVia:"Order lewat",workStatus:"Status pengerjaan",working:"Sedang dikerjakan",waiting:"Menunggu giliran",
  slotsUnset:"Jumlah slot belum diatur",waitlistN:"{n} orang di waitlist",slotsFull:"Slot penuh",slotsLeft:"{n} slot tersisa",
  sumTitle:"Ringkasan untukmu · tidak terlihat pengunjung",sumActive:"Nilai antrean aktif",sumPaid:"Sudah lunas",sumDp:"DP diterima",sumDue:"Sisa tagihan",sumLate:"Lewat deadline",nOrders:"{n} pesanan",
  addPrice:"+ Tambah harga",packageN:"Paket {n}",edit:"Ubah",tiersEmptyEditor:"Belum ada harga. Buka mode edit lalu tambah paket pertama, misalnya Headshot atau Full body.",tiersEmpty:"Artis belum menulis daftar harga.",tiersLoading:"Daftar harga akan muncul di sini.",addonsLabel:"Tambahan (add-on)",
  galleryEmptyEditor:"Belum ada karya. Di mode edit, tekan “+” untuk mengunggah contoh karyamu.",galleryLoading:"Contoh karya akan muncul di sini.",addArt:"Tambah karya",viewArt:"Lihat {t}",artWord:"karya",deleteArt:"Hapus karya",tapAgain:"Tekan sekali lagi untuk menghapus",
  fActive:"Aktif",fDone:"Selesai",fAll:"Semua",addOrder:"+ Pesanan",queueLoading:"Antrean pesanan akan muncul di sini.",doneEmpty:"Belum ada pesanan yang selesai.",queueEmptyEditor:"Antrean kosong. Di mode edit, tekan “+ Pesanan” untuk mencatat klien pertama.",queueEmpty:"Antrean sedang kosong.",
  deadline:"Deadline {d}",late:"Lewat deadline",stageGroup:"Tahap pengerjaan",moveTo:"Pindah ke {s}",
  s_antri:"Antre",s_sketsa:"Sketsa",s_lineart:"Lineart",s_warna:"Warna",s_selesai:"Selesai",p_unpaid:"Belum bayar",p_dp:"DP",p_paid:"Lunas",
  dealPrice:"Harga deal",dpWord:"DP",contactWord:"Kontak",privateEmpty:"Detail privat belum diisi.",
  tosEmptyEditor:"Belum ada ketentuan. Isi lewat “Profil & slot” di mode edit, satu aturan per baris.",tosLoading:"Ketentuan komisi akan muncul di sini.",
  footEditor:"Harga deal, pembayaran, kontak klien, dan catatan hanya terlihat olehmu.",footEditorStatic:"Mode edit lokal: perubahan tersimpan di browser ini saja. Harga deal, pembayaran, kontak, dan catatan tidak ikut ke data.json publik.",footViewer:"",
  copied:"Kontak disalin",copyManual:"Salin manual: {t}",stageUpdated:"Tahap diperbarui",errAccess:"Tidak tersimpan: kamu belum masuk sebagai pemilik, atau sesi login sudah berakhir.",errQuota:"Penyimpanan penuh atau gambar terlalu besar. Hapus karya lama dulu.",errSave:"Gagal menyimpan, coba lagi.",
  preparingImg:"Menyiapkan gambar…",avatarUpdated:"Foto profil diperbarui",artUpdated:"Artwork utama diperbarui",imgBad:"Gambar tidak bisa dibaca. Coba file JPG atau PNG.",
  profileSaved:"Profil disimpan",priceAdded:"Harga ditambahkan",priceSaved:"Harga disimpan",priceDeleted:"Harga dihapus",artAdded:"Karya ditambahkan",artDeleted:"Karya dihapus",orderAdded:"Pesanan dicatat",orderSaved:"Pesanan disimpan",orderDeleted:"Pesanan dihapus",themeSaved:"Tampilan disimpan",
  editMode:"Mode edit",done:"Selesai",profileBtn:"Profil & slot",lookBtn:"Tampilan",
  profileTitle:"Profil & slot",fName:"Nama artis",fTagline:"Tagline",fTaglineEn:"Tagline (English)",fStatus:"Status komisi",fSlots:"Jumlah slot",fContact:"Kontak untuk order",fTos:"Ketentuan (TOS)",fTosEn:"Ketentuan (English)",onePerLine:"Satu aturan per baris.",enOptional:"Opsional. Tampil saat pengunjung memilih English; kalau kosong, versi Indonesia yang dipakai.",
  phTagline:"Ilustrasi anime & semi-realis, full color",phContact:"DM IG @namakamu / email",phTos:"Satu aturan per baris",
  cancel:"Batal",save:"Simpan",del:"Hapus",sureDel:"Yakin hapus?",
  addPriceTitle:"Tambah harga",editPriceTitle:"Ubah harga",fTierName:"Nama",fKind:"Jenis",kindBase:"Paket utama",kindAddon:"Add-on",fPrice:"Harga (Rp)",fDesc:"Keterangan",fOrder:"Urutan tampil",phTierName:"Half body",phDesc:"Full color, 1 karakter, background polos",
  addArtTitle:"Tambah karya",fImage:"Gambar",imgHint:"Gambar otomatis dikecilkan agar ringan dimuat.",fCaption:"Keterangan",phCaption:"Half body · OC milik @klien",pickImgFirst:"Pilih gambar dulu.",
  newOrder:"Pesanan baru",editOrder:"Ubah pesanan",publicSec:"Tampil di antrean publik",fClient:"Nama / handle klien",clientHint:"Yang tertulis di sini terlihat semua pengunjung.",fPackage:"Paket",pickPackage:"Pilih paket",fStage:"Tahap",fAddons:"Add-on",phAddons:"Background, +1 karakter",fDeadline:"Deadline",privateSec:"Privat · hanya kamu",fDeal:"Harga deal (Rp)",dealHint:"Kosongkan untuk pakai harga paket.",fPayment:"Pembayaran",fDp:"Nominal DP (Rp)",fClientContact:"Kontak klien",phClientContact:"WA / email / DM",fNotes:"Catatan referensi",phNotes:"Link referensi, pose, warna, revisi",needPackage:"Pilih paket dulu. Kalau belum ada, tambahkan di bagian Harga.",
  lookTitle:"Tampilan",themeSec:"Tema warna",customTheme:"Kustom",customSec:"Warna kustom",c_deep:"Utama",c_accent:"Aksen",c_soft:"Lembut",c_glow:"Sorotan",c_light:"Terang",
  deepWarn:"Warna utama terlalu terang, teks bisa sulit dibaca. Pilih warna yang lebih gelap.",lightWarn:"Warna terang sebaiknya hampir putih agar kartu tetap terbaca.",
  langSec:"Bahasa default",langHint:"Bahasa yang dilihat pengunjung pertama kali. Mereka tetap bisa pindah ke bahasa lain dari menu atas.",previewNote:"Pratinjau langsung. Tekan Simpan agar semua pengunjung melihat tema ini.",
  backupSec:"Cadangan data",dlBackup:"Unduh cadangan lengkap",importBackup:"Impor cadangan",importDone:"{n} data diimpor",importBad:"File cadangan tidak valid.",backupHint:"Cadangan lengkap berisi semua data termasuk yang privat. Simpan baik-baik, jangan diunggah ke hosting.",
  dlPublic:"Unduh data.json",staticBanner:"Mode edit lokal. Perubahan baru tersimpan di browser ini. Setelah selesai, unduh data.json lalu ganti file data.json di hostingmu agar pengunjung melihatnya.",staticDraft:"Ada perubahan lokal yang belum kamu publikasikan.",discardDraft:"Buang perubahan lokal",discardSure:"Yakin buang semua perubahan?",
  ownerLogin:"Masuk pemilik",logout:"Keluar",loginTitle:"Masuk sebagai pemilik",fEmail:"Email",fPassword:"Password",loginBtn:"Masuk",badLogin:"Email atau password salah.",badPassword:"Password salah.",notAdmin:"Akun ini belum terdaftar sebagai pemilik sheet. Lihat README bagian Supabase.",locked:"Terlalu banyak percobaan. Coba lagi beberapa menit lagi.",loginNet:"Tidak bisa terhubung ke server. Coba lagi."},
en:{nav_beranda:"Home",nav_harga:"Prices",nav_galeri:"Gallery",nav_antrean:"Queue",nav_ketentuan:"Terms",
  st_open:"Open",st_waitlist:"Waitlist",st_closed:"Closed",k_open:"✦ Commissions open",k_waitlist:"✦ Waitlist open",k_closed:"✦ Commissions closed",k_none:"✦ Commissions",
  loading:"Loading sheet…",artistDefault:"Artist name",taglineDefault:"Prices, slots and the commission queue show up here.",taglineEditor:"Turn on edit mode to fill in your profile, prices and queue.",
  loadFail:"Couldn't load the data. Try reloading the page.",notConfigured:"Storage isn't set up yet. Fill in config.js as described in the README.",
  seePrices:"See prices",copyContact:"Copy contact",artHintEditor:"Upload your best artwork in edit mode to show it here.",artHint:"The featured artwork will appear here.",uploadArt:"Upload artwork",changeArt:"Change artwork",changeAvatar:"Change profile photo",
  chipLeft:"<b>{n}</b> slots left",chipFrom:"from <b>{p}</b>",
  slotsMonth:"Slots this month",orderVia:"Order via",workStatus:"Work status",working:"In progress",waiting:"Waiting",
  slotsUnset:"Slot count not set",waitlistN:"{n} on the waitlist",slotsFull:"Slots full",slotsLeft:"{n} slots left",
  sumTitle:"Your summary · hidden from visitors",sumActive:"Active queue value",sumPaid:"Paid in full",sumDp:"Deposits received",sumDue:"Still owed",sumLate:"Past deadline",nOrders:"{n} orders",
  addPrice:"+ Add price",packageN:"Tier {n}",edit:"Edit",tiersEmptyEditor:"No prices yet. Turn on edit mode and add your first tier, like Headshot or Full body.",tiersEmpty:"The artist hasn't listed prices yet.",tiersLoading:"The price list will appear here.",addonsLabel:"Add-ons",
  galleryEmptyEditor:"No artwork yet. In edit mode, tap “+” to upload samples of your work.",galleryLoading:"Sample artwork will appear here.",addArt:"Add artwork",viewArt:"View {t}",artWord:"artwork",deleteArt:"Delete artwork",tapAgain:"Tap again to delete",
  fActive:"Active",fDone:"Done",fAll:"All",addOrder:"+ Order",queueLoading:"The order queue will appear here.",doneEmpty:"No finished orders yet.",queueEmptyEditor:"The queue is empty. In edit mode, tap “+ Order” to log your first client.",queueEmpty:"The queue is empty right now.",
  deadline:"Due {d}",late:"Past deadline",stageGroup:"Work stage",moveTo:"Move to {s}",
  s_antri:"Queued",s_sketsa:"Sketch",s_lineart:"Lineart",s_warna:"Color",s_selesai:"Done",p_unpaid:"Unpaid",p_dp:"Deposit",p_paid:"Paid",
  dealPrice:"Agreed price",dpWord:"Deposit",contactWord:"Contact",privateEmpty:"Private details not filled in.",
  tosEmptyEditor:"No terms yet. Add them under “Profile & slots” in edit mode, one rule per line.",tosLoading:"Commission terms will appear here.",
  footEditor:"Agreed prices, payments, client contacts and notes are visible only to you.",footEditorStatic:"Local edit mode: changes are saved in this browser only. Agreed prices, payments, contacts and notes are never included in the public data.json.",footViewer:"",
  copied:"Contact copied",copyManual:"Copy manually: {t}",stageUpdated:"Stage updated",errAccess:"Not saved: you're not signed in as the owner, or your session expired.",errQuota:"Storage is full or the image is too large. Delete old artwork first.",errSave:"Couldn't save. Try again.",
  preparingImg:"Preparing image…",avatarUpdated:"Profile photo updated",artUpdated:"Featured artwork updated",imgBad:"Couldn't read that image. Try a JPG or PNG file.",
  profileSaved:"Profile saved",priceAdded:"Price added",priceSaved:"Price saved",priceDeleted:"Price deleted",artAdded:"Artwork added",artDeleted:"Artwork deleted",orderAdded:"Order logged",orderSaved:"Order saved",orderDeleted:"Order deleted",themeSaved:"Appearance saved",
  editMode:"Edit mode",done:"Done",profileBtn:"Profile & slots",lookBtn:"Appearance",
  profileTitle:"Profile & slots",fName:"Artist name",fTagline:"Tagline (Indonesian)",fTaglineEn:"Tagline (English)",fStatus:"Commission status",fSlots:"Number of slots",fContact:"Contact for orders",fTos:"Terms (Indonesian)",fTosEn:"Terms (English)",onePerLine:"One rule per line.",enOptional:"Optional. Shown when a visitor picks English; if empty, the Indonesian text is used.",
  phTagline:"Anime & semi-realistic illustration, full color",phContact:"IG DM @yourname / email",phTos:"One rule per line",
  cancel:"Cancel",save:"Save",del:"Delete",sureDel:"Delete for sure?",
  addPriceTitle:"Add price",editPriceTitle:"Edit price",fTierName:"Name",fKind:"Type",kindBase:"Main tier",kindAddon:"Add-on",fPrice:"Price (IDR)",fDesc:"Description",fOrder:"Display order",phTierName:"Half body",phDesc:"Full color, 1 character, plain background",
  addArtTitle:"Add artwork",fImage:"Image",imgHint:"Images are shrunk automatically so they load fast.",fCaption:"Caption",phCaption:"Half body · OC by @client",pickImgFirst:"Pick an image first.",
  newOrder:"New order",editOrder:"Edit order",publicSec:"Shown in the public queue",fClient:"Client name / handle",clientHint:"Everything here is visible to all visitors.",fPackage:"Tier",pickPackage:"Choose a tier",fStage:"Stage",fAddons:"Add-ons",phAddons:"Background, +1 character",fDeadline:"Deadline",privateSec:"Private · only you",fDeal:"Agreed price (IDR)",dealHint:"Leave empty to use the tier price.",fPayment:"Payment",fDp:"Deposit amount (IDR)",fClientContact:"Client contact",phClientContact:"WhatsApp / email / DM",fNotes:"Reference notes",phNotes:"Reference links, pose, colors, revisions",needPackage:"Choose a tier first. If there isn't one yet, add it under Prices.",
  lookTitle:"Appearance",themeSec:"Color theme",customTheme:"Custom",customSec:"Custom colors",c_deep:"Main",c_accent:"Accent",c_soft:"Soft",c_glow:"Highlight",c_light:"Light",
  deepWarn:"The main color is too light; text may be hard to read. Pick a darker color.",lightWarn:"The light color should be close to white so cards stay readable.",
  langSec:"Default language",langHint:"The language visitors see first. They can still switch from the top menu.",previewNote:"Live preview. Press Save so every visitor sees this theme.",
  backupSec:"Data backup",dlBackup:"Download full backup",importBackup:"Import backup",importDone:"{n} items imported",importBad:"That backup file isn't valid.",backupHint:"The full backup includes private data. Keep it safe and never upload it to your hosting.",
  dlPublic:"Download data.json",staticBanner:"Local edit mode. Changes are saved in this browser only. When you're done, download data.json and replace the data.json on your hosting so visitors see it.",staticDraft:"You have local changes that aren't published yet.",discardDraft:"Discard local changes",discardSure:"Discard all changes?",
  ownerLogin:"Owner login",logout:"Log out",loginTitle:"Sign in as owner",fEmail:"Email",fPassword:"Password",loginBtn:"Sign in",badLogin:"Wrong email or password.",badPassword:"Wrong password.",notAdmin:"This account isn't registered as the sheet owner. See the Supabase section of the README.",locked:"Too many attempts. Try again in a few minutes.",loginNet:"Couldn't reach the server. Try again."}
};
let LANG="id";
const t=(k,v={})=>String((T[LANG]&&T[LANG][k])??T.id[k]??k).replace(/\{(\w+)\}/g,(_,x)=>v[x]??"");
function storedLang(){try{const l=localStorage.getItem("cs_lang");return T[l]?l:null}catch(e){return null}}
function setLang(l){LANG=T[l]?l:"id";try{localStorage.setItem("cs_lang",LANG)}catch(e){}document.documentElement.lang=LANG;render()}

/* ---------- themes ---------- */
const PRESETS={
  amethyst:{name:"Amethyst Dream",c:["#290087","#A230A4","#CAC5E5","#F2E0A4","#F6FFE9"]},
  sakura:{name:"Sakura Milk",c:["#5E1A45","#D9488A","#F4C6D9","#FFE3A3","#FFF8F6"]},
  ocean:{name:"Ocean Soda",c:["#0B2A6F","#2F7FD9","#C3DBF7","#FFD98A","#F5FBFF"]},
  matcha:{name:"Matcha Latte",c:["#1D4636","#4F9466","#CFE5C9","#F4D9A6","#FAFFF5"]},
  peach:{name:"Peach Sunset",c:["#561731","#E0604A","#F9D3C4","#FFE2A0","#FFF9F3"]},
  midnight:{name:"Midnight Ink",c:["#1C1B2E","#6C5CE7","#D6D3EE","#FFD3E6","#FAFAFF"]}
};
const isHex=h=>typeof h==="string"&&/^#?[0-9a-fA-F]{6}$/.test(h);
const hx=h=>{h=h.replace("#","");const n=parseInt(h,16);return[(n>>16)&255,(n>>8)&255,n&255]};
const toHex=a=>"#"+a.map(v=>Math.round(Math.max(0,Math.min(255,v))).toString(16).padStart(2,"0")).join("");
const mix=(a,b,w)=>{const A=hx(a),B=hx(b);return toHex(A.map((v,i)=>v*w+B[i]*(1-w)))};
const rgba=(a,o)=>{const A=hx(a);return`rgba(${A[0]},${A[1]},${A[2]},${o})`};
const lum=h=>{const c=hx(h).map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*c[0]+.7152*c[1]+.0722*c[2]};
function themeCSS(c){
  const [deep,acc,soft,glow,light]=c;const W="#ffffff",K="#000000";
  const L={bg:mix(soft,W,.3),dot:rgba(deep,.10),surface:mix(light,W,.5),"surface-2":mix(soft,W,.5),ink:deep,muted:mix(deep,soft,.7),line:mix(soft,W,.75),
    accent:deep,"accent-2":acc,"on-accent":light,"accent-soft":mix(soft,W,.6),"pink-soft":mix(glow,W,.55),vanilla:glow,glow:rgba(glow,.55),
    "hero-a":deep,"hero-b":mix(deep,acc,.5),"hero-c":acc,"on-hero":light,"hero-sub":rgba(light,.86),shadow:`0 14px 34px -22px ${rgba(deep,.55)}`,"shadow-sm":`0 6px 18px -14px ${rgba(deep,.45)}`};
  const dk=mix(deep,K,.8);
  const D={bg:mix(deep,K,.45),dot:rgba(soft,.08),surface:mix(deep,K,.7),"surface-2":mix(dk,soft,.9),ink:light,muted:mix(soft,deep,.85),line:mix(dk,soft,.8),
    accent:soft,"accent-2":mix(acc,W,.6),"on-accent":deep,"accent-soft":mix(dk,soft,.84),"pink-soft":mix(mix(deep,K,.7),glow,.82),vanilla:glow,glow:rgba(glow,.30),
    "hero-a":mix(deep,K,.7),"hero-b":mix(mix(deep,acc,.5),K,.7),"hero-c":mix(acc,K,.8),"on-hero":light,"hero-sub":rgba(light,.84),shadow:"0 14px 34px -22px rgba(0,0,0,.8)","shadow-sm":"0 6px 18px -14px rgba(0,0,0,.7)"};
  const v=o=>Object.entries(o).map(([k,x])=>`--${k}:${x}`).join(";");
  return `:root{${v(L)}}@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){${v(D)};color-scheme:dark}}:root[data-theme="dark"]{${v(D)};color-scheme:dark}`;
}
function themeColors(th){if(th&&th.preset==="custom"&&Array.isArray(th.colors)&&th.colors.length===5&&th.colors.every(isHex))return th.colors.map(x=>x[0]==="#"?x:"#"+x);return(PRESETS[th&&th.preset]||PRESETS.amethyst).c}
function applyTheme(th){const c=themeColors(th);document.getElementById("themeVars").textContent=themeCSS(c);const m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute("content",c[0])}

/* ---------- state + helpers ---------- */
const STAGES=["antri","sketsa","lineart","warna","selesai"];
const PAYS=["unpaid","dp","paid"];
const Store=window.createStore(window.SHEET_CONFIG||{});
const S={config:null,tiers:[],orders:[],priv:{},gallery:[],hero:null,avatar:null,canEdit:false,edit:false,filter:"aktif",loaded:false,langChosen:false,fatal:null};
const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const safeImg=s=>typeof s==="string"&&/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(s)?s:"";
const loc=()=>LANG==="en"?"en-US":"id-ID";
const rp=n=>new Intl.NumberFormat(loc(),{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n)||0);
const fmtDate=d=>{if(!d)return"";const x=new Date(d+"T00:00:00");return isNaN(x)?d:x.toLocaleDateString(loc(),{day:"numeric",month:"short"})};
const today=()=>{const d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")};
const initial=n=>(String(n||"").trim()[0]||"✦").toUpperCase();
const pickText=(id,en)=>LANG==="en"&&en&&String(en).trim()?en:id;
function toast(msg){document.querySelectorAll(".toast").forEach(x=>x.remove());const el=document.createElement("div");el.className="toast";el.setAttribute("role","status");el.textContent=msg;document.body.appendChild(el);setTimeout(()=>el.remove(),2600)}
function download(name,obj){const blob=new Blob([JSON.stringify(obj,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}

/* ---------- render ---------- */
function render(){
  const c=S.config||{};
  document.querySelectorAll("[data-t]").forEach(el=>el.textContent=t(el.dataset.t));
  $("app").classList.toggle("editing",S.edit);
  document.title=(c.artistName?c.artistName+" · ":"")+"Commission Sheet";
  $("artist").textContent=c.artistName||(S.loaded?t("artistDefault"):t("loading"));
  $("tagline").textContent=S.fatal?t(S.fatal):(pickText(c.tagline,c.tagline_en)||(S.loaded&&S.canEdit?t("taglineEditor"):t("taglineDefault")));
  $("kicker").textContent=t("k_"+(c.status||"none"));
  $("heroPrices").textContent=t("seePrices");$("heroCopy").textContent=t("copyContact");$("copyBtn").textContent=t("copyContact");

  const avatar=safeImg(S.avatar),hero=safeImg(S.hero);
  const av=$("avatar");av.innerHTML=avatar?`<img src="${avatar}" alt="">`:esc(initial(c.artistName));
  av.tabIndex=S.edit?0:-1;av.style.cursor=S.edit?"pointer":"default";av.title=S.edit?t("changeAvatar"):"";
  av.onclick=S.edit?()=>pickImage("avatar"):null;
  $("artFrame").innerHTML=(hero?`<img src="${hero}" alt="${esc(c.artistName||"")}">`:
    `<div class="art-empty"><div class="big">${esc(initial(c.artistName))}</div><p>${S.canEdit?t("artHintEditor"):t("artHint")}</p></div>`)+
    (S.edit?`<button class="pill sm art-edit" id="heroEdit">${hero?t("changeArt"):t("uploadArt")}</button>`:"");
  if(S.edit)$("heroEdit").onclick=()=>pickImage("hero");

  const active=S.orders.filter(o=>o.stage!=="selesai");
  const total=Math.max(0,Math.min(40,Number(c.slotsTotal)||0));
  const filled=total?Math.min(active.length,total):active.length;
  $("slotBig").innerHTML=total?`${filled}<small>/${total}</small>`:"–";
  $("slotDots").innerHTML=total?Array.from({length:total},(_,i)=>`<span class="${i<filled?"full":""}"></span>`).join(""):"";
  $("slotNote").textContent=!total?t("slotsUnset"):active.length>total?t("waitlistN",{n:active.length-total}):filled>=total?t("slotsFull"):t("slotsLeft",{n:total-filled});
  const cs=$("chipSlots");cs.hidden=!total;cs.innerHTML=total?t("chipLeft",{n:Math.max(0,total-filled)}):"";
  const tBase=S.tiers.filter(x=>x.kind!=="addon").map(x=>Number(x.price)||0).filter(Boolean);
  const ch=$("chipStart");ch.hidden=!tBase.length;ch.innerHTML=tBase.length?t("chipFrom",{p:rp(Math.min(...tBase))}):"";
  const nWork=active.filter(o=>o.stage!=="antri").length;
  $("nWork").textContent=nWork;$("nWait").textContent=active.length-nWork;
  $("workBar").style.width=(active.length?Math.round(nWork/active.length*100):0)+"%";
  $("contactV").textContent=c.contact||"–";
  $("copyBtn").hidden=!c.contact;$("heroCopy").hidden=!c.contact;
  $("copyBtn").onclick=$("heroCopy").onclick=()=>copy(c.contact);

  $("navEnd").innerHTML=`<span class="lang" role="group" aria-label="Language"><button data-lang="id" class="${LANG==="id"?"on":""}">ID</button><button data-lang="en" class="${LANG==="en"?"on":""}">EN</button></span>`+
    (c.status&&["open","waitlist","closed"].includes(c.status)?`<span class="status" data-s="${c.status}">${t("st_"+c.status)}</span>`:"")+
    (S.canEdit?(S.edit?`<button class="pill ghost sm" id="lookBtn">${t("lookBtn")}</button><button class="pill ghost sm" id="editProfile">${t("profileBtn")}</button>`:"")+`<button class="pill sm ${S.edit?"":"soft"}" id="toggleEdit">${S.edit?t("done"):t("editMode")}</button>`:"");
  document.querySelectorAll("[data-lang]").forEach(b=>b.onclick=()=>{S.langChosen=true;setLang(b.dataset.lang)});
  if(S.canEdit){$("toggleEdit").onclick=()=>{S.edit=!S.edit;try{sessionStorage.setItem("cs_edit_on",S.edit?"1":"")}catch(e){}render()};if(S.edit){$("editProfile").onclick=openConfig;$("lookBtn").onclick=openLook}}

  renderBanner();renderSummary();renderTiers();renderGallery();renderQueue();renderTos();renderViews();renderFoot();
}

function renderBanner(){
  const b=$("banner");
  if(Store.mode==="static"&&S.canEdit){
    b.hidden=false;
    b.innerHTML=`<p>${t("staticBanner")}${Store.hasDraft?" "+t("staticDraft"):""}</p><div class="acts"><button class="pill sm" id="bDl">${t("dlPublic")}</button>${Store.hasDraft?`<button class="pill ghost sm" id="bDiscard">${t("discardDraft")}</button>`:""}</div>`;
    $("bDl").onclick=()=>download("data.json",Store.snapshot(false));
    if($("bDiscard"))armDelete($("bDiscard"),()=>{Store.discardDraft();location.reload()},t("discardSure"),t("discardDraft"));
  }else b.hidden=true;
}

function renderFoot(){
  $("foot").textContent=S.canEdit?(Store.mode==="static"?t("footEditorStatic"):t("footEditor")):t("footViewer");
  const fl=$("footLinks");
  if(Store.supportsLogin&&!S.fatal){
    fl.innerHTML=S.canEdit?`<button class="linkish" id="logoutBtn">${t("logout")}</button>`:`<button class="linkish" id="loginBtn">${t("ownerLogin")}</button>`;
    if($("loginBtn"))$("loginBtn").onclick=openLogin;
    if($("logoutBtn"))$("logoutBtn").onclick=async()=>{await Store.logout();try{sessionStorage.removeItem("cs_edit_on")}catch(e){}location.reload()};
  }else fl.innerHTML="";
}

function renderSummary(){
  const el=$("ownerSum");
  if(!S.canEdit||!S.orders.length){el.hidden=true;return}
  el.hidden=false;
  let tot=0,paid=0,dp=0,due=0,late=0;const d0=today();
  S.orders.forEach(o=>{const p=S.priv[o.id]||{};const v=Number(p.price)||0;
    if(o.stage!=="selesai"){tot+=v;if(o.deadline&&o.deadline<d0)late++}
    if(p.paid==="paid")paid+=v;else if(p.paid==="dp"){dp+=Number(p.dpAmount)||0;due+=Math.max(0,v-(Number(p.dpAmount)||0))}else due+=v});
  el.innerHTML=`<div class="sum"><span class="sum-title">${t("sumTitle")}</span>
    <div><div class="k">${t("sumActive")}</div><div class="v num">${rp(tot)}</div></div>
    <div><div class="k">${t("sumPaid")}</div><div class="v num">${rp(paid)}</div></div>
    <div><div class="k">${t("sumDp")}</div><div class="v num">${rp(dp)}</div></div>
    <div><div class="k">${t("sumDue")}</div><div class="v num">${rp(due)}</div></div>
    <div><div class="k">${t("sumLate")}</div><div class="v num">${t("nOrders",{n:late})}</div></div></div>`;
}

function renderTiers(){
  const base=S.tiers.filter(x=>x.kind!=="addon").sort((a,b)=>(a.order||0)-(b.order||0));
  const add=S.tiers.filter(x=>x.kind==="addon").sort((a,b)=>(a.order||0)-(b.order||0));
  $("priceActs").innerHTML=S.edit?`<button class="pill sm" id="addTier">${t("addPrice")}</button>`:"";
  if(S.edit)$("addTier").onclick=()=>openTier();
  $("tiers").innerHTML=base.length?base.map((x,i)=>`<article class="tier card">
      <span class="tag">${t("packageN",{n:i+1})}</span>
      <h3>${esc(x.name)}</h3><div class="price num">${rp(x.price)}</div>
      ${x.desc?`<p>${esc(x.desc)}</p>`:""}
      ${S.edit?`<div class="acts"><button class="pill ghost sm" data-et="${esc(x.id)}">${t("edit")}</button></div>`:""}
    </article>`).join(""):`<div class="empty">${S.loaded?(S.canEdit?t("tiersEmptyEditor"):t("tiersEmpty")):t("tiersLoading")}</div>`;
  $("addonWrap").hidden=!add.length;
  $("addons").innerHTML=add.map(x=>`<span class="addon"><span class="an">${esc(x.name)}${x.desc?` <span style="color:var(--muted);font-weight:500">· ${esc(x.desc)}</span>`:""}</span><span class="ap num">+${rp(x.price)}</span>${S.edit?`<button data-et="${esc(x.id)}">${t("edit")}</button>`:""}</span>`).join("");
  document.querySelectorAll("[data-et]").forEach(b=>b.onclick=()=>openTier(S.tiers.find(x=>x.id===b.dataset.et)));
}

function renderGallery(){
  const g=[...S.gallery].filter(a=>safeImg(a.src)).sort((a,b)=>(b.createdAt||"").localeCompare(a.createdAt||""));
  if(!g.length&&!S.edit){$("gallery").innerHTML=`<div class="empty">${S.loaded&&S.canEdit?t("galleryEmptyEditor"):t("galleryLoading")}</div>`;return}
  $("gallery").innerHTML=(S.edit&&g.length<12?`<button class="add-art" id="addArt"><span>+</span>${t("addArt")}</button>`:"")+
    g.slice(0,12).map(a=>`<div class="art-wrap"><button class="art" data-art="${esc(a.id)}" aria-label="${esc(t("viewArt",{t:a.title||t("artWord")}))}"><img src="${safeImg(a.src)}" alt="${esc(a.title||t("artWord"))}" loading="lazy">${a.title?`<span class="cap">${esc(a.title)}</span>`:""}</button>${S.edit?`<button class="x" data-delart="${esc(a.id)}" aria-label="${t("deleteArt")}">✕</button>`:""}</div>`).join("");
  if($("addArt"))$("addArt").onclick=openArtwork;
  document.querySelectorAll("[data-art]").forEach(b=>b.onclick=()=>lightbox(S.gallery.find(a=>a.id===b.dataset.art)));
  document.querySelectorAll("[data-delart]").forEach(b=>{b.onclick=()=>{if(b.classList.contains("armed")){guard(()=>Store.remove("gallery",b.dataset.delart),t("artDeleted"))}else{b.classList.add("armed");b.textContent="?";setTimeout(()=>{b.classList.remove("armed");b.textContent="✕"},3000);toast(t("tapAgain"))}}});
}

function renderQueue(){
  const F=[["aktif","fActive"],["selesai","fDone"],["semua","fAll"]];
  $("filters").innerHTML=F.map(([k,l])=>`<button class="pill sm ${S.filter===k?"":"ghost"}" data-f="${k}">${t(l)}</button>`).join("")+(S.edit?`<button class="pill sm alt" id="addOrder">${t("addOrder")}</button>`:"");
  document.querySelectorAll("[data-f]").forEach(b=>b.onclick=()=>{S.filter=b.dataset.f;renderQueue()});
  if(S.edit)$("addOrder").onclick=()=>openOrder();
  const sorted=[...S.orders].sort((a,b)=>(a.createdAt||"").localeCompare(b.createdAt||""));
  const activeIds=sorted.filter(o=>o.stage!=="selesai").map(o=>o.id);
  let list=sorted;
  if(S.filter==="aktif")list=sorted.filter(o=>o.stage!=="selesai");
  if(S.filter==="selesai")list=sorted.filter(o=>o.stage==="selesai").reverse();
  if(!list.length){$("queue").innerHTML=`<div class="empty">${!S.loaded?t("queueLoading"):S.filter==="selesai"?t("doneEmpty"):(S.canEdit?t("queueEmptyEditor"):t("queueEmpty"))}</div>`;return}
  const d0=today();
  $("queue").innerHTML=list.map(o=>{
    const si=Math.max(0,STAGES.indexOf(o.stage));
    const qi=activeIds.indexOf(o.id);const p=S.priv[o.id];
    const late=o.stage!=="selesai"&&o.deadline&&o.deadline<d0;
    const paid=p&&PAYS.includes(p.paid)?p.paid:"unpaid";
    return `<article class="order card${o.stage==="selesai"?" done":""}">
      <div class="o-top"><span class="qn num">${qi>=0?"#"+(qi+1):"✓"}</span>
        <div class="o-main"><div class="o-client">${esc(o.client)}</div><div class="o-meta">${esc(o.tierName||"")}${o.addons?" + "+esc(o.addons):""}</div></div></div>
      <div class="chips">${o.deadline?`<span class="chip num">${esc(t("deadline",{d:fmtDate(o.deadline)}))}</span>`:""}${late?`<span class="chip late">${t("late")}</span>`:""}${S.canEdit&&p?`<span class="chip ${paid}">${t("p_"+paid)}</span>`:""}</div>
      <div class="stages" role="group" aria-label="${t("stageGroup")}">${STAGES.map((k,i)=>`<button class="stg${i<=si?" reached":""}${i===si?" cur":""}" ${S.edit?`data-o="${esc(o.id)}" data-s="${k}" title="${esc(t("moveTo",{s:t("s_"+k)}))}"`:`tabindex="-1" aria-disabled="true"`}><i></i><span>${t("s_"+k)}</span></button>`).join("")}</div>
      ${S.edit?`<div class="o-private">${p?`<span>${t("dealPrice")} <b class="num">${rp(p.price)}</b></span>${p.paid==="dp"&&p.dpAmount?`<span>${t("dpWord")} <b class="num">${rp(p.dpAmount)}</b></span>`:""}${p.contact?`<span>${t("contactWord")} <b>${esc(p.contact)}</b></span>`:""}${p.notes?`<span class="note">${esc(p.notes)}</span>`:""}`:`<span>${t("privateEmpty")}</span>`}
        <button class="pill ghost sm" data-eo="${esc(o.id)}" style="margin-left:auto">${t("edit")}</button></div>`:""}
    </article>`}).join("");
  document.querySelectorAll(".stg[data-o]").forEach(b=>b.onclick=()=>setStage(b.dataset.o,b.dataset.s));
  document.querySelectorAll("[data-eo]").forEach(b=>b.onclick=()=>openOrder(S.orders.find(o=>o.id===b.dataset.eo)));
}

function tosLines(){const c=S.config||{};return(pickText(c.tos,c.tos_en)||"").split("\n").map(s=>s.trim()).filter(Boolean)}
function renderTos(){
  const lines=tosLines();
  $("tos").innerHTML=lines.length?lines.map(l=>`<li>${esc(l)}</li>`).join(""):`<li>${S.loaded&&S.canEdit?t("tosEmptyEditor"):t("tosLoading")}</li>`;
}

/* ---------- screens ---------- */
const VIEWS=["beranda","harga","galeri","antrean","ketentuan"];
let cur=(()=>{const h=(location.hash||"").slice(1);return VIEWS.includes(h)?h:"beranda"})();
function availViews(){
  return VIEWS.filter(k=>k==="galeri"?(!S.loaded||S.canEdit||S.gallery.length>0):k==="ketentuan"?(!S.loaded||S.canEdit||tosLines().length>0):true);
}
function go(id,dir){
  const av=availViews();if(!av.includes(id))id="beranda";
  const oldI=av.indexOf(cur),newI=av.indexOf(id);
  const moved=id!==cur;cur=id;
  try{history.replaceState(null,"",location.pathname+location.search+"#"+id)}catch(e){}
  renderViews(moved?(dir||(newI>=oldI?"r":"l")):null);
  if(moved)window.scrollTo({top:0,behavior:"auto"});
}
function renderViews(anim){
  const av=availViews();
  if(!av.includes(cur))cur="beranda";
  VIEWS.forEach(k=>{const el=$(k);el.hidden=k!==cur;el.classList.remove("in-r","in-l")});
  if(anim){const el=$(cur);void el.offsetWidth;el.classList.add(anim==="r"?"in-r":"in-l")}
  $("navLinks").innerHTML=av.map(k=>`<a href="#${k}" data-go="${k}" class="${k===cur?"active":""}" ${k===cur?'aria-current="page"':""}>${t("nav_"+k)}</a>`).join("");
  const i=av.indexOf(cur),prev=av[i-1],next=av[i+1];
  $("pager").innerHTML=`${prev?`<button class="pill ghost sm" data-go="${prev}" data-dir="l">‹ <span>${t("nav_"+prev)}</span></button>`:`<span class="screen-title">${i+1} / ${av.length}</span>`}
    <div class="dots">${av.map(k=>`<button class="${k===cur?"on":""}" data-go="${k}" aria-label="${t("nav_"+k)}"></button>`).join("")}</div>
    ${next?`<button class="pill sm" data-go="${next}" data-dir="r"><span>${t("nav_"+next)}</span> ›</button>`:`<span class="screen-title">${i+1} / ${av.length}</span>`}`;
  const act=document.querySelector(".nav-links a.active");
  if(act&&act.scrollIntoView)try{act.scrollIntoView({block:"nearest",inline:"nearest"})}catch(e){}
}
document.addEventListener("click",e=>{const a=e.target.closest("[data-go]");if(!a)return;e.preventDefault();go(a.dataset.go,a.dataset.dir)});
(function(){let x0=null,y0=null;const v=$("views");
  v.addEventListener("touchstart",e=>{if(e.touches.length!==1||e.target.closest("input,textarea,select")){x0=null;return}x0=e.touches[0].clientX;y0=e.touches[0].clientY},{passive:true});
  v.addEventListener("touchend",e=>{if(x0==null||$("modalRoot").firstChild)return;const dx=e.changedTouches[0].clientX-x0,dy=e.changedTouches[0].clientY-y0;x0=null;
    if(Math.abs(dx)<70||Math.abs(dx)<Math.abs(dy)*1.6)return;
    const av=availViews(),i=av.indexOf(cur),n=av[i+(dx<0?1:-1)];if(n)go(n,dx<0?"r":"l")},{passive:true});
  document.addEventListener("keydown",e=>{if($("modalRoot").firstChild||(e.target.closest&&e.target.closest("input,textarea,select")))return;
    if(e.key!=="ArrowRight"&&e.key!=="ArrowLeft")return;const av=availViews(),i=av.indexOf(cur),n=av[i+(e.key==="ArrowRight"?1:-1)];if(n)go(n,e.key==="ArrowRight"?"r":"l")});
})();

/* ---------- actions ---------- */
async function copy(text){try{await navigator.clipboard.writeText(text);toast(t("copied"))}catch(e){toast(t("copyManual",{t:text}))}}
async function guard(fn,okMsg){
  try{await fn();if(okMsg)toast(okMsg);if(Store.mode==="static")renderBanner();return true}
  catch(e){console.error(e);const code=e&&e.code;toast(code==="auth"||code==="csrf"?t("errAccess"):code==="quota"||code==="too_large"?t("errQuota"):t("errSave"));return false}
}
async function setStage(id,stage){
  const o=S.orders.find(x=>x.id===id);if(!o||o.stage===stage)return;
  await guard(()=>Store.update("orders",id,{stage,updatedAt:new Date().toISOString()}),t("stageUpdated"));
}
const saveConfig=data=>Store.set("sheet","config",Object.assign({},S.config||{},data));

async function shrink(file,maxSide,maxLen){
  const url=URL.createObjectURL(file);
  try{
    const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=()=>rej(new Error("bad"));i.src=url});
    let side=maxSide,q=.86,out="";
    for(let k=0;k<10;k++){
      const s=Math.min(1,side/Math.max(img.naturalWidth,img.naturalHeight));
      const c=document.createElement("canvas");c.width=Math.max(1,Math.round(img.naturalWidth*s));c.height=Math.max(1,Math.round(img.naturalHeight*s));
      const x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,c.width,c.height);x.drawImage(img,0,0,c.width,c.height);
      out=c.toDataURL("image/jpeg",q);
      if(out.length<=maxLen)return out;
      if(q>.62)q-=.08;else side=Math.round(side*.82);
    }
    throw new Error("big");
  }finally{URL.revokeObjectURL(url)}
}
function pickImage(kind){
  const inp=document.createElement("input");inp.type="file";inp.accept="image/*";
  inp.onchange=async()=>{const f=inp.files[0];if(!f)return;toast(t("preparingImg"));
    let src;try{src=await shrink(f,kind==="avatar"?320:1100,kind==="avatar"?60000:230000)}catch(e){toast(t("imgBad"));return}
    await guard(()=>Store.set("media",kind,{src,updatedAt:new Date().toISOString()}),kind==="avatar"?t("avatarUpdated"):t("artUpdated"))};
  inp.click();
}

/* ---------- modals ---------- */
function modal(html,onMount,cls="",onClose){
  const root=$("modalRoot");
  root.innerHTML=`<div class="overlay ${cls}" id="ov">${cls?html:`<div class="panel" role="dialog" aria-modal="true">${html}</div>`}</div>`;
  let closed=false;
  const close=(saved)=>{if(closed)return;closed=true;root.innerHTML="";document.removeEventListener("keydown",kd);onClose&&onClose(saved===true)};
  const kd=e=>{if(e.key==="Escape")close()};document.addEventListener("keydown",kd);
  $("ov").addEventListener("click",e=>{if(e.target.id==="ov"||cls)close()});
  root.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>close());
  onMount&&onMount(close);
  const f=root.querySelector("input:not([type=color]):not([type=file]),select,textarea");f&&f.focus();
}
function lightbox(a){if(!a||!safeImg(a.src))return;modal(`<img src="${safeImg(a.src)}" alt="${esc(a.title||t("artWord"))}">${a.title?`<p>${esc(a.title)}</p>`:""}`,null,"lightbox")}
function armDelete(btn,fn,sure,label){btn.onclick=()=>{if(btn.classList.contains("armed")){fn()}else{btn.classList.add("armed");btn.textContent=sure||t("sureDel");setTimeout(()=>{btn.classList.remove("armed");btn.textContent=label||t("del")},3500)}}}
const actsHTML=(withDel,delId)=>`<div class="acts">${withDel?`<button type="button" class="pill danger" id="${delId}" style="margin-right:auto">${t("del")}</button>`:""}<button type="button" class="pill ghost" data-close>${t("cancel")}</button><button class="pill" type="submit">${t("save")}</button></div>`;

function openLogin(){
  const needEmail=Store.loginNeedsEmail;
  modal(`<h3>${t("loginTitle")}</h3>
    <form id="fli" style="display:contents">
    ${needEmail?`<div class="field"><label for="li_email">${t("fEmail")}</label><input id="li_email" type="email" autocomplete="username" required></div>`:""}
    <div class="field"><label for="li_pass">${t("fPassword")}</label><input id="li_pass" type="password" autocomplete="current-password" required></div>
    <p class="err" id="li_err" hidden></p>
    <div class="acts"><button type="button" class="pill ghost" data-close>${t("cancel")}</button><button class="pill" type="submit" id="li_go">${t("loginBtn")}</button></div></form>`,
  close=>{
    $("fli").onsubmit=async e=>{e.preventDefault();$("li_go").disabled=true;$("li_err").hidden=true;
      try{await Store.login(needEmail?$("li_email").value.trim():"",$("li_pass").value);try{sessionStorage.setItem("cs_edit_on","1")}catch(x){}location.reload()}
      catch(x){$("li_err").hidden=false;$("li_err").textContent=x.code==="not_admin"?t("notAdmin"):x.code==="locked"?t("locked"):x.code==="net"?t("loginNet"):(needEmail?t("badLogin"):t("badPassword"));$("li_go").disabled=false}};
  });
}

function openLook(){
  const saved=(S.config&&S.config.theme)||{preset:"amethyst"};
  const sel={preset:saved.preset||"amethyst",colors:(saved.colors&&saved.colors.length===5&&saved.colors.every(isHex))?[...saved.colors]:[...PRESETS.amethyst.c]};
  const keys=["c_deep","c_accent","c_soft","c_glow","c_light"];
  modal(`<h3>${t("lookTitle")}</h3>
    <form id="fl" style="display:contents">
    <div class="sub">${t("themeSec")}</div>
    <div class="themes" id="themeList"></div>
    <div id="customBox" hidden style="display:flex;flex-direction:column;gap:8px">
      <div class="sub">${t("customSec")}</div>
      <div class="custom-grid">${keys.map((k,i)=>`<label for="cc${i}"><input type="color" id="cc${i}" value="${esc(sel.colors[i])}">${t(k)}</label>`).join("")}</div>
      <p class="hint" id="cWarn" hidden></p>
    </div>
    <small style="color:var(--muted);font-size:12px">${t("previewNote")}</small>
    <div class="sub" style="margin-top:4px">${t("langSec")}</div>
    <div class="field"><label for="l_lang" style="font-weight:600;color:var(--muted)">${t("langHint")}</label><select id="l_lang"><option value="id" ${(S.config?.lang||"id")==="id"?"selected":""}>Bahasa Indonesia</option><option value="en" ${S.config?.lang==="en"?"selected":""}>English</option></select></div>
    <div class="sub" style="margin-top:4px">${t("backupSec")}</div>
    <div class="tool-row"><button type="button" class="pill ghost sm" id="bkDl">${t("dlBackup")}</button><button type="button" class="pill ghost sm" id="bkIn">${t("importBackup")}</button>${Store.mode==="static"?`<button type="button" class="pill ghost sm" id="bkPub">${t("dlPublic")}</button>`:""}</div>
    <small style="color:var(--muted);font-size:12px">${t("backupHint")}</small>
    ${actsHTML(false)}</form>`,
  close=>{
    const draw=()=>{
      $("themeList").innerHTML=Object.entries(PRESETS).map(([k,p])=>`<button type="button" class="theme-opt ${sel.preset===k?"on":""}" data-th="${k}"><span class="sw">${p.c.map(x=>`<i style="background:${x}"></i>`).join("")}</span>${esc(p.name)}</button>`).join("")+
        `<button type="button" class="theme-opt ${sel.preset==="custom"?"on":""}" data-th="custom"><span class="sw">${sel.colors.map(x=>`<i style="background:${esc(x)}"></i>`).join("")}</span>${t("customTheme")}</button>`;
      $("customBox").hidden=sel.preset!=="custom";
      document.querySelectorAll("[data-th]").forEach(b=>b.onclick=()=>{sel.preset=b.dataset.th;applyTheme(sel);draw()});
      const w=[];if(lum(sel.colors[0])>.2)w.push(t("deepWarn"));if(lum(sel.colors[4])<.75)w.push(t("lightWarn"));
      $("cWarn").hidden=!w.length;$("cWarn").textContent=w.join(" ");
    };
    keys.forEach((_,i)=>$("cc"+i).addEventListener("input",e=>{sel.colors[i]=e.target.value;sel.preset="custom";applyTheme(sel);draw()}));
    draw();
    $("bkDl").onclick=()=>download("commission-backup-"+today()+".json",Store.snapshot(true));
    if($("bkPub"))$("bkPub").onclick=()=>download("data.json",Store.snapshot(false));
    $("bkIn").onclick=()=>{const inp=document.createElement("input");inp.type="file";inp.accept="application/json,.json";
      inp.onchange=async()=>{const f=inp.files[0];if(!f)return;let obj;try{obj=JSON.parse(await f.text())}catch(e){toast(t("importBad"));return}
        try{const n=await Store.importAll(obj);toast(t("importDone",{n}));close(true);if(Store.mode==="static")renderBanner()}catch(e){toast(e.code==="bad_import"?t("importBad"):e.code==="auth"?t("errAccess"):t("errSave"))}};
      inp.click()};
    $("fl").onsubmit=async e=>{e.preventDefault();
      const theme=sel.preset==="custom"?{preset:"custom",colors:sel.colors}:{preset:sel.preset};
      const lang=$("l_lang").value;
      if(await guard(()=>saveConfig({theme,lang}),t("themeSaved")))close(true)};
  },"",ok=>{if(!ok)applyTheme(S.config&&S.config.theme)});
}

function openConfig(){
  const c=S.config||{};
  modal(`<h3>${t("profileTitle")}</h3>
    <form id="fc" style="display:contents">
    <div class="field"><label for="c_name">${t("fName")}</label><input id="c_name" required maxlength="60" value="${esc(c.artistName)}"></div>
    <div class="field"><label for="c_tag">${t("fTagline")}</label><input id="c_tag" maxlength="140" value="${esc(c.tagline)}" placeholder="${esc(T.id.phTagline)}"></div>
    <div class="field"><label for="c_tag_en">${t("fTaglineEn")}</label><input id="c_tag_en" maxlength="140" value="${esc(c.tagline_en)}" placeholder="${esc(T.en.phTagline)}"><small>${t("enOptional")}</small></div>
    <div class="row2">
      <div class="field"><label for="c_status">${t("fStatus")}</label><select id="c_status">${["open","waitlist","closed"].map(k=>`<option value="${k}" ${c.status===k?"selected":""}>${t("st_"+k)}</option>`).join("")}</select></div>
      <div class="field"><label for="c_slots">${t("fSlots")}</label><input id="c_slots" type="number" min="0" max="40" value="${esc(c.slotsTotal??5)}"></div>
    </div>
    <div class="field"><label for="c_contact">${t("fContact")}</label><input id="c_contact" maxlength="120" value="${esc(c.contact)}" placeholder="${esc(t("phContact"))}"></div>
    <div class="field"><label for="c_tos">${t("fTos")}</label><textarea id="c_tos" maxlength="3000" placeholder="${esc(t("phTos"))}">${esc(c.tos)}</textarea><small>${t("onePerLine")}</small></div>
    <div class="field"><label for="c_tos_en">${t("fTosEn")}</label><textarea id="c_tos_en" maxlength="3000" placeholder="${esc(T.en.phTos)}">${esc(c.tos_en)}</textarea><small>${t("enOptional")}</small></div>
    ${actsHTML(false)}</form>`,
  close=>{$("fc").onsubmit=async e=>{e.preventDefault();
    const data={artistName:$("c_name").value.trim(),tagline:$("c_tag").value.trim(),tagline_en:$("c_tag_en").value.trim(),status:$("c_status").value,
      slotsTotal:Math.max(0,Math.min(40,parseInt($("c_slots").value)||0)),contact:$("c_contact").value.trim(),tos:$("c_tos").value,tos_en:$("c_tos_en").value};
    if(await guard(()=>saveConfig(data),t("profileSaved")))close(true)}});
}

function openArtwork(){
  let src="";
  modal(`<h3>${t("addArtTitle")}</h3>
    <form id="fa" style="display:contents">
    <div class="field"><label for="a_file">${t("fImage")}</label><input id="a_file" type="file" accept="image/*" required><small>${t("imgHint")}</small></div>
    <img class="preview" id="a_prev" alt="" hidden>
    <div class="field"><label for="a_title">${t("fCaption")}</label><input id="a_title" maxlength="60" placeholder="${esc(t("phCaption"))}"></div>
    <p class="err" id="a_err" hidden></p>
    ${actsHTML(false)}</form>`,
  close=>{
    const save=document.querySelector("#fa button[type=submit]");
    $("a_file").onchange=async()=>{const f=$("a_file").files[0];if(!f)return;save.disabled=true;$("a_err").hidden=true;
      try{src=await shrink(f,1100,230000);$("a_prev").src=src;$("a_prev").hidden=false}catch(e){$("a_err").hidden=false;$("a_err").textContent=t("imgBad")}
      save.disabled=false};
    $("fa").onsubmit=async e=>{e.preventDefault();if(!src){$("a_err").hidden=false;$("a_err").textContent=t("pickImgFirst");return}
      if(await guard(()=>Store.set("gallery",Store.newId(),{src,title:$("a_title").value.trim(),createdAt:new Date().toISOString()}),t("artAdded")))close(true)};
  });
}

function openTier(x){
  const isNew=!x;x=x||{kind:"base",order:S.tiers.length+1};
  modal(`<h3>${isNew?t("addPriceTitle"):t("editPriceTitle")}</h3>
    <form id="ft" style="display:contents">
    <div class="field"><label for="t_name">${t("fTierName")}</label><input id="t_name" required maxlength="60" value="${esc(x.name)}" placeholder="${esc(t("phTierName"))}"></div>
    <div class="row2">
      <div class="field"><label for="t_kind">${t("fKind")}</label><select id="t_kind"><option value="base" ${x.kind!=="addon"?"selected":""}>${t("kindBase")}</option><option value="addon" ${x.kind==="addon"?"selected":""}>${t("kindAddon")}</option></select></div>
      <div class="field"><label for="t_price">${t("fPrice")}</label><input id="t_price" type="number" min="0" step="1000" required value="${esc(x.price??"")}"></div>
    </div>
    <div class="field"><label for="t_desc">${t("fDesc")}</label><input id="t_desc" maxlength="160" value="${esc(x.desc)}" placeholder="${esc(t("phDesc"))}"></div>
    <div class="field"><label for="t_order">${t("fOrder")}</label><input id="t_order" type="number" value="${esc(x.order??1)}"></div>
    ${actsHTML(!isNew,"t_del")}</form>`,
  close=>{
    $("ft").onsubmit=async e=>{e.preventDefault();
      const data={name:$("t_name").value.trim(),kind:$("t_kind").value,price:Math.max(0,Number($("t_price").value)||0),desc:$("t_desc").value.trim(),order:Number($("t_order").value)||0};
      if(await guard(()=>Store.set("tiers",isNew?Store.newId():x.id,data),isNew?t("priceAdded"):t("priceSaved")))close(true)};
    if(!isNew)armDelete($("t_del"),async()=>{if(await guard(()=>Store.remove("tiers",x.id),t("priceDeleted")))close(true)});
  });
}

function openOrder(o){
  const isNew=!o;o=o||{stage:"antri"};const p=(o.id&&S.priv[o.id])||{paid:"unpaid"};
  const base=S.tiers.filter(x=>x.kind!=="addon").sort((a,b)=>(a.order||0)-(b.order||0));
  modal(`<h3>${isNew?t("newOrder"):t("editOrder")}</h3>
    <form id="fo" style="display:contents">
    <div class="sub">${t("publicSec")}</div>
    <div class="field"><label for="o_client">${t("fClient")}</label><input id="o_client" required maxlength="60" value="${esc(o.client)}" placeholder="@client"><small>${t("clientHint")}</small></div>
    <div class="row2">
      <div class="field"><label for="o_tier">${t("fPackage")}</label><select id="o_tier"><option value="">${t("pickPackage")}</option>${base.map(x=>`<option value="${esc(x.id)}" data-price="${Number(x.price)||0}" data-name="${esc(x.name)}" ${o.tierId===x.id?"selected":""}>${esc(x.name)} · ${rp(x.price)}</option>`).join("")}${o.tierId&&!base.find(x=>x.id===o.tierId)?`<option value="${esc(o.tierId)}" data-name="${esc(o.tierName)}" selected>${esc(o.tierName)}</option>`:""}</select></div>
      <div class="field"><label for="o_stage">${t("fStage")}</label><select id="o_stage">${STAGES.map(k=>`<option value="${k}" ${o.stage===k?"selected":""}>${t("s_"+k)}</option>`).join("")}</select></div>
    </div>
    <div class="row2">
      <div class="field"><label for="o_addons">${t("fAddons")}</label><input id="o_addons" maxlength="120" value="${esc(o.addons)}" placeholder="${esc(t("phAddons"))}"></div>
      <div class="field"><label for="o_deadline">${t("fDeadline")}</label><input id="o_deadline" type="date" value="${esc(o.deadline)}"></div>
    </div>
    <div class="sub" style="margin-top:6px">${t("privateSec")}</div>
    <div class="row2">
      <div class="field"><label for="o_price">${t("fDeal")}</label><input id="o_price" type="number" min="0" step="1000" value="${esc(p.price??"")}"><small>${t("dealHint")}</small></div>
      <div class="field"><label for="o_paid">${t("fPayment")}</label><select id="o_paid">${PAYS.map(k=>`<option value="${k}" ${p.paid===k?"selected":""}>${t("p_"+k)}</option>`).join("")}</select></div>
    </div>
    <div class="row2">
      <div class="field" id="dpField"><label for="o_dp">${t("fDp")}</label><input id="o_dp" type="number" min="0" step="1000" value="${esc(p.dpAmount??"")}"></div>
      <div class="field"><label for="o_contact">${t("fClientContact")}</label><input id="o_contact" maxlength="120" value="${esc(p.contact)}" placeholder="${esc(t("phClientContact"))}"></div>
    </div>
    <div class="field"><label for="o_notes">${t("fNotes")}</label><textarea id="o_notes" maxlength="2000" placeholder="${esc(t("phNotes"))}">${esc(p.notes)}</textarea></div>
    <p class="err" id="o_err" hidden></p>
    ${actsHTML(!isNew,"o_del")}</form>`,
  close=>{
    const syncDp=()=>{$("dpField").style.visibility=$("o_paid").value==="dp"?"visible":"hidden"};syncDp();$("o_paid").onchange=syncDp;
    $("fo").onsubmit=async e=>{e.preventDefault();
      const sel=$("o_tier").selectedOptions[0];
      if(!$("o_tier").value){$("o_err").hidden=false;$("o_err").textContent=t("needPackage");return}
      const id=isNew?Store.newId():o.id;const now=new Date().toISOString();
      const pub={client:$("o_client").value.trim(),tierId:$("o_tier").value,tierName:sel.dataset.name||"",addons:$("o_addons").value.trim(),
        deadline:$("o_deadline").value,stage:$("o_stage").value,createdAt:o.createdAt||now,updatedAt:now};
      const priceIn=$("o_price").value;
      const priv={price:priceIn!==""?Number(priceIn):Number(sel.dataset.price||p.price||0),paid:$("o_paid").value,
        dpAmount:$("o_paid").value==="dp"?Number($("o_dp").value)||0:0,contact:$("o_contact").value.trim(),notes:$("o_notes").value};
      if(await guard(async()=>{await Store.set("orders",id,pub);await Store.set("private",id,priv)},isNew?t("orderAdded"):t("orderSaved")))close(true)};
    if(!isNew)armDelete($("o_del"),async()=>{if(await guard(async()=>{await Store.remove("orders",o.id);await Store.remove("private",o.id)},t("orderDeleted")))close(true)});
  });
}

/* ---------- boot ---------- */
LANG=storedLang()||"id";S.langChosen=!!storedLang();document.documentElement.lang=LANG;
applyTheme(null);
render();
(async()=>{
  try{const r=await Store.init();S.canEdit=!!r.canEdit}
  catch(e){console.error(e);S.loaded=true;S.fatal=e&&e.code==="not_configured"?"notConfigured":"loadFail";render();return}
  try{S.edit=S.canEdit&&(sessionStorage.getItem("cs_edit_on")==="1"||(Store.mode==="static"))}catch(e){S.edit=S.canEdit&&Store.mode==="static"}
  const seen=new Set();const ready=k=>{seen.add(k);if(seen.size>=3)S.loaded=true;render()};
  let lastTheme="";
  Store.watch("sheet",rows=>{const c=rows.find(r=>r.id==="config");S.config=c?c.data:null;
    const th=JSON.stringify((S.config&&S.config.theme)||null);if(th!==lastTheme&&!$("modalRoot").firstChild){lastTheme=th;applyTheme(S.config&&S.config.theme)}
    if(!S.langChosen&&S.config&&T[S.config.lang]){LANG=S.config.lang;document.documentElement.lang=LANG}
    ready("c")});
  Store.watch("tiers",rows=>{S.tiers=rows.map(r=>Object.assign({},r.data,{id:r.id}));ready("t")});
  Store.watch("orders",rows=>{S.orders=rows.map(r=>Object.assign({},r.data,{id:r.id}));ready("o")});
  Store.watch("gallery",rows=>{S.gallery=rows.map(r=>Object.assign({},r.data,{id:r.id}));render()});
  Store.watch("media",rows=>{S.hero=null;S.avatar=null;rows.forEach(r=>{if(r.id==="hero")S.hero=r.data.src;if(r.id==="avatar")S.avatar=r.data.src});render()});
  if(S.canEdit)Store.watch("private",rows=>{const m={};rows.forEach(r=>m[r.id]=r.data);S.priv=m;render()});
})();
})();
