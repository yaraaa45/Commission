/*
 * Commission Sheet — lapisan penyimpanan.
 * Satu antarmuka, tiga backend: static (data.json), supabase, php.
 * Data disimpan sebagai dokumen JSON: koleksi → id → objek.
 * Koleksi: sheet (config), tiers, orders, private, gallery, media.
 * "private" (harga deal, pembayaran, kontak klien, catatan) hanya untuk pemilik.
 */
(function () {
  "use strict";
  const COLLECTIONS = ["sheet", "tiers", "orders", "private", "gallery", "media"];
  const PUBLIC = COLLECTIONS.filter(c => c !== "private");

  const err = (code, message) => Object.assign(new Error(message || code), { code });
  const clone = o => JSON.parse(JSON.stringify(o));

  class BaseStore {
    constructor(cfg) { this.cfg = cfg; this.cache = {}; this.subs = {}; this.loaded = {}; this.canEdit = false; }
    rows(col) { return Object.entries(this.cache[col] || {}).map(([id, data]) => ({ id, data })); }
    emit(col) { (this.subs[col] || []).forEach(cb => { try { cb(this.rows(col)); } catch (e) { console.error(e); } }); }
    watch(col, cb) {
      (this.subs[col] || (this.subs[col] = [])).push(cb);
      if (this.loaded[col]) cb(this.rows(col)); else this.load(col);
    }
    newId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
    put(col, id, data) { (this.cache[col] || (this.cache[col] = {}))[id] = data; this.emit(col); }
    drop(col, id) { if (this.cache[col]) delete this.cache[col][id]; this.emit(col); }
    async update(col, id, patch) {
      const cur = (this.cache[col] || {})[id];
      if (!cur) throw err("missing");
      return this.set(col, id, Object.assign({}, cur, patch));
    }
    snapshot(includePrivate) {
      const out = {};
      (includePrivate ? COLLECTIONS : PUBLIC).forEach(c => { out[c] = clone(this.cache[c] || {}); });
      return out;
    }
    validateImport(obj) {
      if (!obj || typeof obj !== "object" || Array.isArray(obj)) throw err("bad_import");
      const clean = {};
      Object.keys(obj).forEach(c => {
        if (!COLLECTIONS.includes(c)) return;
        const docs = obj[c];
        if (!docs || typeof docs !== "object" || Array.isArray(docs)) return;
        clean[c] = {};
        Object.keys(docs).forEach(id => {
          if (/^[A-Za-z0-9_\-]{1,128}$/.test(id) && docs[id] && typeof docs[id] === "object" && !Array.isArray(docs[id])) clean[c][id] = docs[id];
        });
      });
      if (!Object.keys(clean).length) throw err("bad_import");
      return clean;
    }
  }

  /* ---------------- static: data.json + local draft ---------------- */
  class StaticStore extends BaseStore {
    constructor(cfg) { super(cfg); this.mode = "static"; this.supportsLogin = false; this.draftKey = "cs_static_draft_v1"; }
    async init() {
      const params = new URLSearchParams(location.search);
      this.canEdit = params.has("edit");
      let base = {};
      try {
        const r = await fetch(this.cfg.dataUrl || "data.json", { cache: "no-store" });
        if (!r.ok) throw err("net", "HTTP " + r.status);
        base = await r.json();
      } catch (e) {
        if (!this.canEdit) throw err("load_failed", e.message);
      }
      this.base = base || {};
      let data = this.base;
      this.hasDraft = false;
      if (this.canEdit) {
        try {
          const raw = localStorage.getItem(this.draftKey);
          if (raw) { data = JSON.parse(raw); this.hasDraft = true; }
        } catch (e) { /* storage blocked: edit in memory only */ }
      }
      COLLECTIONS.forEach(c => { this.cache[c] = clone((data && data[c]) || {}); this.loaded[c] = true; });
      if (!this.canEdit) this.cache.private = {};
      return { canEdit: this.canEdit };
    }
    load(col) { this.loaded[col] = true; this.emit(col); }
    persist() {
      if (!this.canEdit) throw err("auth");
      try { localStorage.setItem(this.draftKey, JSON.stringify(this.snapshot(true))); this.hasDraft = true; }
      catch (e) { throw err("quota"); }
    }
    async set(col, id, data) { if (!this.canEdit) throw err("auth"); this.put(col, id, clone(data)); this.persist(); }
    async remove(col, id) { if (!this.canEdit) throw err("auth"); this.drop(col, id); this.persist(); }
    async importAll(obj) {
      if (!this.canEdit) throw err("auth");
      const clean = this.validateImport(obj); let n = 0;
      Object.keys(clean).forEach(c => { this.cache[c] = clean[c]; n += Object.keys(clean[c]).length; this.emit(c); });
      this.persist(); return n;
    }
    discardDraft() { try { localStorage.removeItem(this.draftKey); } catch (e) {} this.hasDraft = false; }
  }

  /* ---------------- supabase ---------------- */
  const SUPABASE_JS = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js";
  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = document.createElement("script"); s.src = src; s.async = true;
      s.onload = res; s.onerror = () => rej(err("net", "Gagal memuat " + src));
      document.head.appendChild(s);
    });
  }
  class SupabaseStore extends BaseStore {
    constructor(cfg) { super(cfg); this.mode = "supabase"; this.supportsLogin = true; this.loginNeedsEmail = true; this.reloadTimers = {}; }
    async init() {
      if (!this.cfg.supabaseUrl || !this.cfg.supabaseAnonKey) throw err("not_configured");
      if (!window.supabase) await loadScript(SUPABASE_JS);
      this.sb = window.supabase.createClient(this.cfg.supabaseUrl, this.cfg.supabaseAnonKey);
      const { data } = await this.sb.auth.getSession();
      this.session = data && data.session;
      this.canEdit = this.session ? await this.checkAdmin() : false;
      this.sb.channel("docs-changes")
        .on("postgres_changes", { event: "*", schema: "public", table: "docs" }, p => {
          const col = (p.new && p.new.collection) || (p.old && p.old.collection);
          if (col) this.scheduleReload(col); else PUBLIC.forEach(c => this.scheduleReload(c));
        })
        .subscribe();
      return { canEdit: this.canEdit };
    }
    async checkAdmin() {
      const uid = this.session && this.session.user && this.session.user.id;
      if (!uid) return false;
      const { data, error } = await this.sb.from("sheet_admins").select("user_id").eq("user_id", uid).maybeSingle();
      return !error && !!data;
    }
    scheduleReload(col) { clearTimeout(this.reloadTimers[col]); this.reloadTimers[col] = setTimeout(() => this.load(col), 400); }
    async load(col) {
      if (col === "private" && !this.canEdit) { this.cache[col] = {}; this.loaded[col] = true; this.emit(col); return; }
      const { data, error } = await this.sb.from("docs").select("id,data").eq("collection", col);
      if (error) { console.error(error); this.loaded[col] = true; this.emit(col); return; }
      const m = {}; (data || []).forEach(r => { m[r.id] = r.data || {}; });
      this.cache[col] = m; this.loaded[col] = true; this.emit(col);
    }
    mapError(error) {
      if (!error) return null;
      const msg = (error.message || "") + " " + (error.code || "");
      if (/row-level security|permission|42501|JWT/i.test(msg)) return err("auth", error.message);
      return err("net", error.message);
    }
    async set(col, id, data) {
      if (!this.canEdit) throw err("auth");
      const { error } = await this.sb.from("docs").upsert({ collection: col, id, data, updated_at: new Date().toISOString() });
      if (error) throw this.mapError(error);
      this.put(col, id, clone(data));
    }
    async remove(col, id) {
      if (!this.canEdit) throw err("auth");
      const { error } = await this.sb.from("docs").delete().eq("collection", col).eq("id", id);
      if (error) throw this.mapError(error);
      this.drop(col, id);
    }
    async importAll(obj) {
      if (!this.canEdit) throw err("auth");
      const clean = this.validateImport(obj); let n = 0;
      for (const c of Object.keys(clean)) {
        const rows = Object.keys(clean[c]).map(id => ({ collection: c, id, data: clean[c][id], updated_at: new Date().toISOString() }));
        for (let i = 0; i < rows.length; i += 20) {
          const { error } = await this.sb.from("docs").upsert(rows.slice(i, i + 20));
          if (error) throw this.mapError(error);
        }
        n += rows.length; await this.load(c);
      }
      return n;
    }
    async login(email, password) {
      const { data, error } = await this.sb.auth.signInWithPassword({ email, password });
      if (error) throw err("bad_login", error.message);
      this.session = data.session;
      const ok = await this.checkAdmin();
      if (!ok) { await this.sb.auth.signOut(); throw err("not_admin"); }
      this.canEdit = true; return true;
    }
    async logout() { await this.sb.auth.signOut(); this.canEdit = false; }
  }

  /* ---------------- php + mysql ---------------- */
  class PhpStore extends BaseStore {
    constructor(cfg) { super(cfg); this.mode = "php"; this.supportsLogin = true; this.loginNeedsEmail = false; this.csrf = null; this.stamps = null; }
    async api(action, { method = "GET", params = {}, body } = {}) {
      const url = new URL(this.cfg.phpApiUrl || "api/api.php", location.href);
      url.searchParams.set("action", action);
      Object.keys(params).forEach(k => url.searchParams.set(k, params[k]));
      const headers = {};
      if (body !== undefined) headers["Content-Type"] = "application/json";
      if (this.csrf) headers["X-CSRF-Token"] = this.csrf;
      let r;
      try { r = await fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, credentials: "include", cache: "no-store" }); }
      catch (e) { throw err("net", e.message); }
      let j = null; try { j = await r.json(); } catch (e) {}
      if (!r.ok) {
        const code = j && j.error;
        if (r.status === 401 || r.status === 403) throw err(code === "locked" ? "locked" : code === "bad_login" ? "bad_login" : "auth");
        if (r.status === 413) throw err("quota");
        throw err(code || "net");
      }
      return j;
    }
    async init() {
      const me = await this.api("me");
      this.canEdit = !!(me && me.canEdit); this.csrf = me && me.csrf;
      this.poll();
      return { canEdit: this.canEdit };
    }
    async load(col) {
      if (col === "private" && !this.canEdit) { this.cache[col] = {}; this.loaded[col] = true; this.emit(col); return; }
      try {
        const j = await this.api("list", { params: { collection: col } });
        const m = {}; (j.docs || []).forEach(r => { m[r.id] = r.data || {}; });
        this.cache[col] = m;
      } catch (e) { console.error(e); }
      this.loaded[col] = true; this.emit(col);
    }
    poll() {
      const sec = Math.max(5, Number(this.cfg.pollSeconds) || 20);
      const tick = async () => {
        if (!document.hidden) {
          try {
            const j = await this.api("stamp");
            const next = j.stamps || {};
            if (this.stamps) {
              Object.keys(this.subs).forEach(c => {
                const a = JSON.stringify(this.stamps[c] || null), b = JSON.stringify(next[c] || null);
                if (a !== b) this.load(c);
              });
            }
            this.stamps = next;
          } catch (e) { /* offline: try again next tick */ }
        }
        setTimeout(tick, sec * 1000);
      };
      tick();
    }
    async set(col, id, data) {
      if (!this.canEdit) throw err("auth");
      await this.api("set", { method: "POST", body: { collection: col, id, data } });
      this.put(col, id, clone(data));
    }
    async update(col, id, patch) {
      if (!this.canEdit) throw err("auth");
      await this.api("update", { method: "POST", body: { collection: col, id, data: patch } });
      const cur = (this.cache[col] || {})[id] || {};
      this.put(col, id, Object.assign({}, cur, clone(patch)));
    }
    async remove(col, id) {
      if (!this.canEdit) throw err("auth");
      await this.api("delete", { method: "POST", body: { collection: col, id } });
      this.drop(col, id);
    }
    async importAll(obj) {
      if (!this.canEdit) throw err("auth");
      const clean = this.validateImport(obj);
      const j = await this.api("import", { method: "POST", body: { data: clean } });
      for (const c of Object.keys(clean)) await this.load(c);
      return j.count || 0;
    }
    async login(_email, password) {
      const j = await this.api("login", { method: "POST", body: { password } });
      this.csrf = j.csrf; this.canEdit = true; return true;
    }
    async logout() { try { await this.api("logout", { method: "POST", body: {} }); } catch (e) {} this.canEdit = false; this.csrf = null; }
  }

  window.createStore = function (cfg) {
    cfg = cfg || {};
    if (cfg.backend === "supabase") return new SupabaseStore(cfg);
    if (cfg.backend === "php") return new PhpStore(cfg);
    return new StaticStore(cfg);
  };
})();
