# Commission Sheet — versi mandiri

Website commission sheet yang bisa kamu hosting sendiri di domain mana pun, tanpa kaitan dengan platform lain. Pengunjung tidak perlu login apa pun untuk melihat harga, galeri, antrean, dan ketentuan.

Fiturnya sama dengan versi sebelumnya: lima layar (Beranda, Harga, Galeri, Antrean, Ketentuan) dengan geser/tombol, 6 tema warna + warna kustom, bahasa Indonesia/English, mode edit, unggah artwork dan galeri, tahap pengerjaan, serta catatan pembayaran privat.

## Isi folder

| File | Fungsi |
|---|---|
| `index.html`, `styles.css`, `app.js` | Tampilan website |
| `store.js` | Penghubung ke penyimpanan (statis, Supabase, atau PHP) |
| `config.js` | **Satu-satunya file yang perlu kamu ubah** untuk memilih penyimpanan |
| `data.json` | Data publik untuk mode statis (sudah berisi data sheet kamu saat ini) |
| `api/` | Backend PHP + MySQL (hanya untuk mode PHP) |
| `supabase/schema.sql` | Skema database untuk mode Supabase |
| `tools/backup-awal.json` | Cadangan lengkap data saat ini, termasuk data privat. Untuk diimpor ke Supabase/PHP. **Jangan diunggah ke hosting.** |
| `tools/hash-password.php` | Pembuat hash password untuk mode PHP |

## Pilih penyimpanan

| | Statis | Supabase | PHP + MySQL |
|---|---|---|---|
| Biaya | Gratis | Gratis (paket free) | Sesuai hosting kamu |
| Hosting | Netlify, GitHub Pages, Vercel, cPanel | Netlify, GitHub Pages, Vercel, cPanel | Hosting PHP (cPanel, dll.) |
| Edit dari web | Ya, lalu unduh `data.json` dan upload ulang | Ya, langsung tersimpan | Ya, langsung tersimpan |
| Data privat (harga deal, pembayaran, kontak klien) | Hanya di browser kamu | Tersimpan aman, hanya pemilik | Tersimpan aman, hanya pemilik |
| Update terlihat pengunjung | Setelah upload ulang | Langsung (realtime) | ±20 detik |

Ganti nilai `backend` di `config.js` menjadi `"static"`, `"supabase"`, atau `"php"`.

---

## A. Statis (paling simpel)

1. Biarkan `backend: "static"` di `config.js`.
2. Upload semua file **kecuali** folder `api/`, `supabase/`, dan `tools/` ke hosting statis. Cara termudah:
   - **Netlify:** buka app.netlify.com → *Add new site* → *Deploy manually* → seret foldernya.
   - **GitHub Pages:** buat repository, upload file, lalu *Settings → Pages → Deploy from branch*.
3. Selesai. Linknya misalnya `namamu.netlify.app`.

**Cara mengedit:**
1. Buka website kamu dengan tambahan `?edit` di akhir alamat, misalnya `namamu.netlify.app/?edit`.
2. Edit seperti biasa (profil, harga, galeri, antrean, tampilan). Perubahan tersimpan di browser itu.
3. Tekan **Unduh data.json** di banner atas, lalu ganti file `data.json` di hosting dengan file baru itu.

Catatan:
- Orang lain yang mengetik `?edit` hanya mengubah tampilan di browser mereka sendiri. Website asli tidak berubah.
- Harga deal, pembayaran, kontak klien, dan catatan **tidak pernah** masuk ke `data.json` publik. Data itu hanya ada di browser tempat kamu mengedit. Simpan cadangannya lewat **Tampilan → Unduh cadangan lengkap**.

---

## B. Supabase (gratis, edit langsung dari web)

1. Daftar di supabase.com dan buat **New project**.
2. Buka **SQL Editor → New query**, tempel isi `supabase/schema.sql`, lalu **Run**.
3. Buka **Authentication → Users → Add user → Create new user**. Isi email dan password kamu, lalu centang *Auto Confirm User*.
4. Kembali ke **SQL Editor** dan jalankan baris ini (ganti emailnya):
   ```sql
   insert into public.sheet_admins (user_id) select id from auth.users where email = 'emailmu@contoh.com';
   ```
5. Disarankan: **Authentication → Sign In / Providers → Email**, matikan *Allow new users to sign up*.
6. Buka **Project Settings → API**. Salin *Project URL* dan kunci *anon public* ke `config.js`:
   ```js
   backend: "supabase",
   supabaseUrl: "https://xxxx.supabase.co",
   supabaseAnonKey: "eyJhbGciOi...",
   ```
   Kunci *anon* memang aman dipasang di website. Yang menjaga data adalah aturan di `schema.sql`: pengunjung hanya bisa membaca, data privat dan penulisan hanya untuk akun di `sheet_admins`. **Jangan** pernah memakai kunci *service_role*.
7. Upload file website (tanpa `api/` dan `tools/`) ke Netlify, GitHub Pages, atau Vercel, sama seperti mode statis.
8. Buka website, tekan **Masuk pemilik** di paling bawah, lalu login.
9. Pindahkan data lama: **Mode edit → Tampilan → Impor cadangan**, lalu pilih `tools/backup-awal.json`.

---

## C. PHP + MySQL (hosting sendiri)

Butuh PHP 7.4 atau lebih baru dengan PDO MySQL (standar di hampir semua cPanel).

1. Upload semua file (kecuali `supabase/` dan `tools/backup-awal.json`) ke `public_html` atau subfolder.
2. Di cPanel → **MySQL Databases**, buat database dan user, lalu beri user itu akses penuh ke database.
3. Buka **phpMyAdmin**, pilih database tadi, buka tab **SQL**, tempel isi `api/schema.sql`, lalu **Go**.
4. Salin `api/config.sample.php` menjadi `api/config.php`, lalu isi nama database, user, dan password.
5. Buat hash password pemilik:
   - Lewat browser: buka `domainmu/tools/hash-password.php`, isi password, salin hasilnya. **Hapus folder `tools/` dari hosting setelahnya.**
   - Atau lewat terminal: `php tools/hash-password.php "passwordmu"`

   Tempel hasilnya (diawali `$2y$`) ke `admin_password_hash` di `api/config.php`.
6. Di `config.js`, ganti menjadi `backend: "php"`.
7. Buka website, tekan **Masuk pemilik**, lalu masukkan password.
8. Pindahkan data lama: **Mode edit → Tampilan → Impor cadangan**, lalu pilih `tools/backup-awal.json` dari komputermu.

Catatan:
- Pakai HTTPS (SSL gratis biasanya tersedia di cPanel lewat AutoSSL) supaya sesi login aman.
- Login dikunci 5 menit setelah 5 kali salah password.
- File `api/.htaccess` mencegah `config.php` dibuka dari luar (Apache/LiteSpeed). Di Nginx, blokir manual folder `api/config.php` dan `data/`.
- **Tanpa MySQL?** Bisa pakai SQLite. Isi `db_dsn` dengan `'sqlite:' . __DIR__ . '/../data/sheet.sqlite'` dan `db_user`/`db_pass` dengan `null`. Buat tabelnya dari `api/schema.sqlite.sql`. Folder `data/` sudah diberi `.htaccess` agar file database tidak bisa diunduh. Lebih aman lagi bila file database ditaruh di luar `public_html`.
- Kalau website dan API beda domain, isi `allowed_origin` di `config.php` dan `phpApiUrl` di `config.js` dengan alamat lengkap API. Keduanya wajib HTTPS.

---

## Domain sendiri

Semua pilihan di atas bisa memakai domain sendiri (misalnya `vyerin.art`):
- **Netlify / Vercel:** *Domain settings → Add domain*, lalu ikuti petunjuk DNS.
- **GitHub Pages:** *Settings → Pages → Custom domain*.
- **cPanel:** arahkan domain ke hosting, lalu upload ke folder domain itu.

## Hal penting lainnya

- **Gambar** dikecilkan otomatis di browser (sekitar 230 KB per gambar) dan disimpan di database atau `data.json`. Galeri dibatasi 12 karya agar website tetap cepat.
- **Cadangan:** buat rutin lewat **Tampilan → Unduh cadangan lengkap**. File itu berisi data privat, jadi simpan di tempat aman dan jangan diunggah ke hosting.
- **Ganti warna dan bahasa:** Mode edit → **Tampilan**. Pengunjung juga bisa pindah ID/EN dari menu atas.
- Tautan langsung ke satu layar: tambahkan `#harga`, `#galeri`, `#antrean`, atau `#ketentuan` di akhir alamat.
