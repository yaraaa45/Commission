/*
 * Commission Sheet — pengaturan
 * Pilih SATU penyimpanan di "backend". Panduan lengkap ada di README.md.
 */
window.SHEET_CONFIG = {
  // "static"   : data dibaca dari data.json. Edit lewat ?edit lalu unduh data.json dan upload ulang.
  // "supabase" : data tersimpan di Supabase (gratis), edit langsung dari web setelah login.
  // "php"      : data tersimpan di MySQL lewat api/api.php di hosting kamu sendiri.
  backend: "static",

  // --- static ---
  dataUrl: "data.json",

  // --- supabase --- (Project Settings → API)
  supabaseUrl: "",       // contoh: "https://abcdxyz.supabase.co"
  supabaseAnonKey: "",   // "anon public" key (aman untuk browser; keamanan diatur oleh RLS di supabase/schema.sql)

  // --- php ---
  phpApiUrl: "api/api.php",
  pollSeconds: 20        // seberapa sering pengunjung mengecek data baru (detik)
};
